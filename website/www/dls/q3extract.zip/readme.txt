==============================
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
Q3 Chat Log Extractor
Version 1.0
http://bg.tnlsoft.com
-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
===============================

=============================================================
Homepage	: http://bg.tnlsoft.com
Contact Email	: evilshafe@hotmail.com
=============================================================
Author: Shafe -- http://bg.tnlsoft.com

This program and it's source code is in the Public Domain.  The source code is included in the Archive.


=====================
OVERVIEW
=====================
Q3 Chat extractor will take logfiles from most q3 based games and extract only the chat text to a separate file.  You may optionally output chatlines with specific keywords on them.  

Q3 Chat Extractor strips all q3 color codes so those do not have to be included 
in any searches.

Basically this makes it easy to read what people are saying on your server, or if your looking for something in particular in your logfile this will help.


=========
PLATFORMS 
=========
q3extract should run on linux, mac and windows.

q3extract is a command line utility.  There is no graphical UI.  It should run on all platforms.  

For WINDOWS:
I have included q3extract.exe which you'll need to go to your command prompt to run.   If you dont know how to use the command prompt this is all probably over your head.

MAC and LINUX
q3extract is written in perl most linux and mac default installs have perl installed so you'll want to run the q3extract.pl file.


============
INSTALLATION
============
Just unzip and move the files to wherever you plan to use them.  Your logfile folder would be a common sense place but anywhere will do.


======
USUAGE
======

Windows:

	q3extract <infile> <outfile> <search (optional)>

Or on linux/mac:

	./q3extract.pl <infile> <outfile> <search (optional)>



	The command line options are as follows:

	infile - 	infile is the log file you wish to extract chat from

	outfile - 	is the file that will be written with only the chat lines

	search - 	if you want to only include chatlines with a particular word 
			that word should be the 3rd parameter.  This is optional.


LINUX/MAC EXAMPLES:
Extract games.log to a file called todayschat.txt put it in the /home/www folder:

	./q3extract.pl games.log /home/www/todayschat.txt


Extracts chat from games.log in the .stvef/baseEF directory.  Put the output in /home/www/todayschat.txt and only show chatlines by shafe or where someone says his name. 
	./q3extract.pl /.stvef/baseEF/games.log /home/www/todayschat.txt shafe


WINDOWS EXAMPLES:
extracts games.log to a file called C:\chat.txt.

	q3extract games.log C:\chat.txt

Extracts chat from games.log. Puts the output in C:\chat.txt and only show chatlines by shafe or where someone says his name. 

	q3extract games.log C:\chat.txt shafe



======================================
By Shafe
Written In Perl