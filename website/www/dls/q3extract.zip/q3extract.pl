#!/usr/bin/perl

	print "\n\nQ3 Chat Extractor Version 1.0\n";
	print "2006 By Shafe\n";
	print "http://www.tnlsoft.com\n";
	print "\n";
	print "This program and it's source code is in the Public Domain.\n";
	print "\n";

if (!@ARGV) 
{
	&ShowHelp;

} else {

	$infile = $ARGV[0];
	$outfile = $ARGV[1];

	$search = $ARGV[2];

	# Check for some stuff that people will probably try on the command line
	$tmpinfile = $infile;	
	$tmpinfile =~ tr/A-Z/a-z/;

	if (($tmpinfile eq "-?") or ($tmpinfile eq "--help") or ($tmpinfile eq "/?")) 
	{ 
		&ShowHelp; 
		exit;
	}


	if ($search eq "") 
	{ 
		print "Converting $infile.... \n";
	} else {
		print "Converting $infile only outputting lines with the term \'$search\' in them.... \n";
	}



	open (OUTPUT, ">>$outfile") || &ShowHelp("ERROR! Could not open the output file for writing.");
	open(FILE, "$infile") || &ShowHelp("ERROR! Could not read the input file!\n");

       while(<FILE>) 
	{
              chop;
              @all = split(/\n/);
              foreach $line (@all) 
		{

        		if ($line =~ /say/)
			{ 

                		#Try To Strip out color codes -- Yeah I know theres a one line way.. this just makes it easy to read
                		$out = ($line =~ s/\^1//g);
		              $out = ($line =~ s/\^2//g);
                		$out = ($line =~ s/\^3//g);
                		$out = ($line =~ s/\^4//g);
                		$out = ($line =~ s/\^5//g);
                		$out = ($line =~ s/\^6//g);
                		$out = ($line =~ s/\^7//g);
                		$out = ($line =~ s/\^8//g);
                		$out = ($line =~ s/\^9//g);
                		$out = ($line =~ s/\^0//g);

				# There is a search specified
				if ($search ne "") 
				{         
					# For simplicity lets not make the search case sensitive
					$tmpline = $line;
					$tmpline =~ tr/A-Z/a-z/;
					$search =~ tr/A-Z/a-z/;

					if ($tmpline =~ /$search/)
					{
						print "$line\n";
						print OUTPUT "$line\n"; 
					}
				} else {

					# No search just spit it out
					print "$line\n";
					print OUTPUT "$line\n"; 
				}

			}
		}
	}
	close(FILE);
	close(OUTPUT);

	print "\n";
	print "Conversion complete.\n";

}

exit;

sub ShowHelp {

	local($message) = @_;
	if ($message ne "") 
	{
		print "\n\t$message\n";
	
	}

	print "Q3 Chat extractor will take logfiles from most q3 based games and extract only the chat text to a \nseparate file.  You may optionally output chatlines with specific keywords on them\n.  Q3 Chat Extractor strips all q3 color codes so those do not have to be included \nin any searches\n";
	print "\n";
	print "Usuage:\n";
	print "\n";
	print "q3extract <infile> <outfile> <search (optional)>\n";
	print "\n";
	print "infile - infile is the log file you wish to extract chat from\n";
	print "outfile - is the file that will be written with only the chat lines\n";
	print "search - if you want to filter out chatlines with a particular word that word should be the 3rd parameter\n\n";
	exit;
	}



