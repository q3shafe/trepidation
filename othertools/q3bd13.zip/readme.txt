QUAKE 3 BOT DESIGNER
v1.3

Designed by Cricel
cricel472@hotmail.com

Q3BD can be found at:

http://www.q3seek.com/cricel/q3bd/


Vaguely Legal stuff:

DISTRIBUTE THIS.  I'm telling you to.  I WANT people to use this.
HOWEVER: If you are going to do anything vaguely commercial with this
like put it on a CD or sell it to your friends or anything REMOTELY
similar, you owe me at least some credit and probably some cash then.
Don't make me have to find out the hard way.  That said: DISTRIBUTE IT!


NOTE: This only works in 800x600 and above.  I strongly recommend
using 1024x 768 when running this program.  This is due to the size of
one of the dialogs.  If I get enough complaints I might work something
out but until then, this is the way it is.  You shouldn't be running
less than 800x600 anyway...


First of all: If you do not want to read through my moderately
windy speech about q3bd, jump down to the line that says *IMPORTANT*
because it is.  If you will grant me the chance to talk about my new
program and continue on, the important stuff is not so important that
it can't wait until you're done reading this.

OK, so you've just made your nice shiny new model.  You're feeling
pretty good.  But what is this?  You can't play against your new model
as a computer opponent...  You need some schmuck (read: friend) to sit
around and test it with you.  That makes life kind of troublesome when
working out the kinks.  And what about all those soon to be raving
fans of yours?  How are THEY going to really see it in action unless
they find someone online who is using it?  Well, you make a bot of
course.

Now, obviously, the above is mostly just for my own entertainment.
If you've got this, you probably know at least something about bots
and models already (at least I hope you do).  So what does this program
do?  Well, if you've ever tried to add bot support to your model once
before, you might have found it a bit involving.  You have to go into
the source code, open some stuff up and type in some numbers and see
what happens.  I'd like to say that those days are over and done with,
you'll never had to look at it again but then, I'd be lying and you'd
be mad at me.  So we'll make it easy:

Q3BD does this:  It provides a VERY nice, VERY easy and VERY smooth
graphical (Windows) interface to all of that bot editing you had to do
before.  You slide these nice little sliders around and save your bots
(without actually making multiple copies of all those nasty _c.c, _t.c,
_i.c and _w.c files).  Everything is contained in a very small -- very
portable -- .q3b file that opens up and saves very cleanly in q3bd.
Then when you're finally done tinkering to your heart's content, all
you need do is click on "Create Q3 Source" and it will make it all for
you...  SO much easier I assure you.  Try it out and see...

Now a few things to mention:  1) You still more or less need to know
what goes in those files.  Designing a bot for Q3 is just far too
complicated to actually remove understanding of the basic principles
from the user of a program like this.  You need to know what the
different categories refer to.  I have made a few arbitrary sections
to make it easier to see everything but all in all it should seem
straightforward.  I would like to hope that it is also fairly intuitive.

Note: I have to admit that I do not actually make models myself.  I
came into this from the programming side because I was flipping through
all the stuff in the pak0.pk3 file and found these piles of files with
bots names and I was just like, wow, what are these?  Looked through,
saw the potential and figured it would make a neat program.  So here it
is.  I tried to do my best with it and I hope you can find some vague
use for it here and there.  Therefore, if there is anything missing that
needs to be added or anything you would like to see added or anything
that just plain sucks and needs to get ripped out or replaced: tell me.
My email address is in q3bd's about and at the top of this file.

***IMPORTANT***
[especially #2]

However, as I DO come from the programming side I can tell you a few
things about these files that some of you might not have known before:

1) contrary to what some (very much including myself) have said, you
do NOT need to use bots.txt to get your bot into q3.  Q3BD will generate
for you what q3 really wants: a .bot file.  It's very simple, very easy
and all done automatically for you.  With a .bot file you just dump it
into the scripts dir and then q3 will recognize it.  This is very good
because, previously, using bots.txt the model downloader will have to
make a new bots.txt for all of his new models.  Now he needs know nothing
at all about it and all of the old bots.txt you might've created along
the way you can chuck.

2) Things that need be known about the chat conversation statements made by bots:

OK, with version 1.3, the bot chat system has been revamped COMPLETELY in Q3BD.
Here's how things work now: You go to Chat Convos, you click on one of the chats
you want to work on.  Let's say you pick Game Exit.  You will note that you have
10 slots to put in chats and then down at the bottom there are a droplist and a
button that says "Insert into chat comment".  The droplist should say: "#BOT_NAME#".
Click on the droplist, note the other choices.  Click on Death Telefrag.  Note that
now the droplist says "#KILLER_NAME#".  Click on the droplist and note that there
are no others.  Now, click in Response 5 and type this:

I'll get you next time , you bastard!

Note: NO quotation marks at the start and end.

Now click right in front of the comma and click on the Insert into chat comment
button.  Note how #KILLER_NAME# is inserted into the chat statement.  What this
does is when the bot says this statement, the bot will insert the name of the
player that killed the bot (this statement can only be initiated after the bot has
been killed).

This is the way it is for all of the chat convos.  What is displayed in the droplist
changes depending on what chat you are editing.  The lists are explained below:

Level Responses:
#BOT_NAME# = the bot's name
#RANDOM_PLAYER# = random opponent
#FIRST_PLACE# = opponent in first place
#LAST_PLACE# = opponent in last place
#LEVEL_NAME# = level's title

Hit Responses:
with hit_talking and hit_nodeath:
#SHOOTER_NAME# = guy who shot the bot
with hit_nokill:
#TARGET_NAME# = guy who didn't die

Death Responses:
#KILLER_NAME# = guy who killed the bot

Kill Responses:
#VICTIM_NAME# = guy the bot killed

Random Responses:
with random_insult:
#RANDOM_PLAYER2# = name of randomly chosen player (other than bot)
#LAST_VICTIM# = bot's last victim's name
with random_misc:
#RANDOM_PLAYER2# = name of randomly chosen player (other than bot)
#BOT_NAME2# = bot's name

Note: the reason for the RANDOM_PLAYER2 and BOT_NAME2 is due to the way that
q3 has some things set up, it's not important.  Just remember that the 2 is
for q3bd, not for you.  It's still the same random player picking and the
name of the bot making the statement (respectively).

However, there is some possiblity of inconsistency with the #BOT_NAME2#
because in some places in the original id bots' chats (_t.c files) this is
sometimes referred to as bot name and sometimes as last victim.  However,
the only time I have seen it used (note, I didn't check TOO hard -- only 5
bots or so) was in Klesk's comments where it is used to refer to Klesk's
name (I think).  So, I figured it must be bot name all the time and made it
so in q3bd.  It might be wrong.  If it is, inform me so I can work something
out.


If you want to really expand on it, there are actually more things you can
insert into the bots' convos, words this time, these are explained in
MrElusive's Q3BotEdit file, available at just about any major q3 news site.
Try www.planetquake.com if you don't know any others.  It's there somewhere.

The way to insert those is like this:

Be ready my friend ", fighter, ": it is a glorious day to die...

Have fun, enjoy the program.


Things to be said:

- Your settings (the stuff in the general settings dialog and the model
dir and .q3b dir) will be saved on exit (in q3d.ini, it's text).
- Make Default Bot saves the current bot (except for the bot's name and
the bot model name) in defbot.ini (this is actually a .q3b file but renamed)
which is then used as the bot skills, personalities, chats, etc when
creating a new bot.
- Once again: I have made efforts to make stuff intuitive and obvious
but I have used the names and setup as it is in the source code.  That
means you need to at least sort of understand what goes into the source
code even tho you do not need to edit the source yourself.  Read
MrElusive's Q3BotEdit!!
- Base Model Dir is the base directory for all of your model files -- the
one that you will zip with subdirectories for making a pk3. botfiles\bots
will be added to the end of this for when the source is generated.
This can be adjusted in the General Settings.
- You will need to associate .q3b files with q3bd yourself.
- Fun names: This is if you want to add color to the bot's name ingame.
i.e. if you want to name your bot Bob and you want Bob to be in red,
put Bob in the name slot on the main page and then in the fun name slot
put ^1Bob.  Color can NOT be added to the Bot Name slot.  It MUST be
put in the Fun Name slot.  Leave this blank if you don't mind if the name
shows up as a regular white in the game.  By in the game I mean when you
run your mouse cursor over the bot and on the high scores list and when the
bot's name is displayed in the console for whatever reason.
Again: normally you will probably want to leave this blank just because
that's the standard.  If you want to add color to the name, change it.
Otherwise: Leave it blank.
Also take note that if you want to put a space in a bot's name, that must
be put into the funname NOT in the regular name.
- Bot Folder which is if you keep a separate folder for each bot (as I do)
you can just let Q3BD make it based on the bot's name or set it yourself.
If you want it to generate only in the Base Dir, give it a bot folder of
nothing (and hit ok) or you can turn this off completely in the general
settings menu.

- If you use Q3BD to create a bot for your model, please mention Q3BD in
your bot's readme.  I like to know and I like seeing how people use it.
This also applies in that I would prefer that you leave all of the comments
that q3bd adds to your bot files (about the file begin generated by q3bd).
I put them there, I would prefer that you not take them out afterwards to
hide the fact.


Known issues that should be mentioned in the readme:

- since you don't install this program, I can't set a variable to know
where q3bd is located.  Therefore, the q3bd.ini will pop up in whatever
folder you use when you start q3bd.  So, normally this won't affect things
because you'll always be starting q3bd by itself in a consistent directory.
However, if you double click open a bot (after associating .q3bs with q3bd)
then your settings (and if you save your defbot.ini) will be saved in the
directory that the bot was in that you opened up.  I don't want to use any
registry keys because that would mean I would have to set up an install
process for q3bd and that would more than double the size of q3bd and there
is no function in MFC/MSVC that I know of to get the exe's directory.  If
someone can help me out here, it would be greatly appreciated.
- Apply All DOES work for Chat Convos now and does NOT save your settings
automatically.  This applies also to the droplist changing of skills in the
dialogs -- if you make changes to one skil level and then change to another
and make changes there, hitting OK will save BOTH of them, hitting cancel
will save NEITHER of them.
- There ARE browse for folder buttons for .q3b Dir and Base Model Dir now.
- There might be some glitches here and there with the advanced skill changing.
- To put a space into a bot's name you need to put it in the Fun Name.  It
MUST be in the funname because the regular name MUST be one word or else you
will not be able to load your bot in q3.
- There IS now a Read Q3 Source option.  You need to select the .bot file and
q3bd will read everything in.  However: take note that this does NOT work with
.bot files nor _c.c, etc, files that are in a pk3.  Also note that it does NOT
work with bots.txt.  You will need to extract sarge_c.c (or whatever) and all
the other associated files and then make a .bot file for him and then read in
that .bot file.  The .bot file and associated files MUST be in a dir tree like
this:

basedir\scripts\[botname].bot
basedir\botfiles\[aifile as described in .bot file]

Note that every aifile that I know of refers to a "bots/[botname]_c.c" so yes, this
means that your aifile will probably have to be in

basedir\botfiles\bots\[botname]_c.c

Although this is not guaranteed (it's completely up to you).




***Error Messages and what to do about them***

"File not saved, error opening file"
"File not saved, error writing file"
-> there was an error creating your .q3b file...  Is your drive write protected?

"File not loaded, error opening file"
-> there was an error opening your .q3b file...  Does the file really exist?

"File not loaded, error reading file"
-> there was an error loading your .q3b file...  Is it really a .q3b file?

"Source not created, error opening main file"
-> I think if you give it a name that won't work as a name this might happen...

"No directory given for source generation"
-> Give it a Base Model Dir (go to settings, Base Model Dir)

"You need a name for this Bot"
-> Give it a name

"You need a main file for this Bot"
-> Click on Main file info on the main page and give it a main file
	i.e. you HAVE to click OK on the main file info dialog
	note that this is the only one that you HAVE to hit ok for,
	everything else in here will be automatically created based
	on the bot's name if you do not hit ok on the appropriate dialog

"Source not created, error opening [weapon/item/chat] [weights/convos] file"
"Source created, but error opening .bot file"
-> Check your File Locations dialog make sure everything is set up properly there
	typically this happens if something is wrong with your directory tree

"Default bot not set, error opening file"
-> Same as file not saved.  It's the same thing anyway just with a set name (defbot.ini)

"Source not read, error opening .bot file"
-> Couldn't find your .bot file that you selected...  Does it exist?

"Source not read, error opening main file"
-> Your .bot file points to a main file that does not exist

"Source not read, could not find skill"
-> you don't have all the skills (1,4,5) in your main file

"Source not read, could not find skill's matching brace"
-> Your skills need to have an opening brace and a closing brace, this
	will happen if your file is improperly made

"Source not read, error opening item/weapon weights / chat convos file"
-> Your main file points to files that aren't there...


If all else fails, email me.  I reply quickly (usually).  email once more:

cricel472@hotmail.com

And once again, q3bd's site:

http://www.q3seek.com/cricel/q3bd/



Version History:

1.0 ->
- Release

1.05 ->
- Fixed glitch with file locations dialog
- Added "Note:"s to File Locations and Chat Responses dialogs
- Set tab orders in all dialogs

1.1 -> (old .q3b files will NOT open properly)
- .bot file name is now based on bot name rather than model name
- made the skill level text boxes not tab stops (they won't start highlighted now)
- added fun (colored) name support
- Added slot to give skin (could be done before by using model/skin in model slot)
- Fixed/added mnemonics (the shortcut keys) here and there
- Fixed problem with naming the skill 4 and skill 5 weights and convos files in the
	main (_c.c) file.

1.3 ->
- SORT OF fixed q3bd.ini and defbot.ini to be in the program folder
- change defaults to be real defaults (default_c.c, etc)
- add Browse for folders buttons
- load/convert [name]_c.c, etc into q3bd
- make it drop down boxes instead of text boxes
- set up top of botfiles like MrElusive's
- fix tab order again
- added chat convo special vars
- apply to all works for chat convos
- apply all does NOT save the settings automatically any more
- fixed personality var dialog bug (settings were not being saved properly)
- added Bot Folder to Base Model Dir dialog and setting to disable this
- added New Bot selection on File menu to clear the current bot
